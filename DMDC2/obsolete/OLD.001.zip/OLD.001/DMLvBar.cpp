// DMLvBar.cpp : �C���v�������e�[�V���� �t�@�C��
//

#include "stdafx.h"
#include "exp00069.h"
#include "DMLvBar.h"
#include <afxpriv.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDMLvBar

BEGIN_MESSAGE_MAP(CDMLvBar, CControlBar)
	//{{AFX_MSG_MAP(CDMLvBar)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_SIZEPARENT, OnSizeParent)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDMLvBar ���b�Z�[�W �n���h��

void CDMLvBar::OnSize(UINT nType, int cx, int cy) 
{
	RepositionBars(0, 0xffff, IDW_DMLVSELBAR, reposDefault);

	CControlBar::OnSize(nType, cx, cy);
}

LRESULT CDMLvBar::OnSizeParent(WPARAM wParam, LPARAM lParam)
{
	AFX_SIZEPARENTPARAMS* lpLayout = (AFX_SIZEPARENTPARAMS*)lParam;

	LRESULT lResult = CControlBar::OnSizeParent(wParam, lParam);

	return lResult;
}

BOOL CDMLvBar::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo) 
{
//	switch (nID) {
//	case IDC_EDIT_LVCX:
//	case IDC_EDIT_LVCY:
//	case IDW_DMLVSELBAR:
//		return GetParent()->OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
//	}
	
	return CControlBar::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}
