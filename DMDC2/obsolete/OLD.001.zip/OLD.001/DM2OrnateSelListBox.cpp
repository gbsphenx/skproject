// DM2OrnateSelListBox.cpp : �C���v�������e�[�V���� �t�@�C��
//

#include "stdafx.h"
#include "exp00069.h"
#include "DM2OrnateSelListBox.h"
#include "CompatDC.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDM2OrnateSelComboBox

CDM2OrnateSelComboBox::CDM2OrnateSelComboBox()
{
	m_ot = otWall;
}

BEGIN_MESSAGE_MAP(CDM2OrnateSelComboBox, CComboBox)
	//{{AFX_MSG_MAP(CDM2OrnateSelComboBox)
		// ���� - ClassWizard �͂��̈ʒu�Ƀ}�b�s���O�p�̃}�N����ǉ��܂��͍폜���܂��B
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDM2OrnateSelComboBox ���b�Z�[�W �n���h��

void CDM2OrnateSelComboBox::Revert(CDM2OrnateIdxArray &oia, bool fRevert)
{
	if (fRevert) {
		m_oia = oia;
	} else {
		oia = m_oia;
	}
}

void CDM2OrnateSelComboBox::Recalc()
{
	m_cy = 66;

	SetItemHeight(-1, m_cy);

	{
		int nBaseNo = m_fHaveNo ? 1 : 0;

		int nOld = GetCount();
		int nNew = m_oia.Size();
		int nDelta = (nBaseNo +_MIN(m_nMax, nNew+1)) - nOld;
		while (nDelta < 0) {
			DeleteString(GetCount() - 1);
			nDelta++;
		}
		while (nDelta > 0) {
			int i = AddString(_T("Text"));
			SetItemHeight(i, m_cy);
			nDelta--;
		}
	}
	{
		m_vec.RemoveAll();
		if (m_fHaveNo) m_vec.Add(-1);
		int i, n = m_oia.Size();
		for (i = 0; i < n && i < m_nMax; i++)
			m_vec.Add(i);
		if (i < m_nMax) m_vec.Add(-2);
	}
}

void CDM2OrnateSelComboBox::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	CDC *pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
	CRect rc = lpDrawItemStruct->rcItem;
	UINT i = lpDrawItemStruct->itemID;
	int z = -3;
	if (i < m_vec.GetSize()) z = (int)m_vec[i];

	if (pDC == NULL) return;

	BOOL fSel = (lpDrawItemStruct->itemState & ODS_SELECTED);

	COLORREF clrBack = GetSysColor(fSel ? COLOR_HIGHLIGHT : COLOR_WINDOW);
	COLORREF clrText = GetSysColor(fSel ? COLOR_HIGHLIGHTTEXT : COLOR_WINDOWTEXT);

	CBrush br;
	br.CreateSolidBrush(clrBack);
	pDC->FillRect(&rc, &br);

	CRect rcBox = rc;
	rcBox.DeflateRect(1, 1);

	pDC->SetBkColor(clrBack);
	pDC->SetTextColor(clrText);

	if (z == -1) {
		pDC->DrawText(_T("(No)"), &rcBox, 0 |DT_LEFT |DT_VCENTER |DT_SINGLELINE);
	} else if (z == -2) {
		pDC->DrawText(_T("(Add new one...)"), &rcBox, 0 |DT_LEFT |DT_VCENTER |DT_SINGLELINE);
	} else if (z == -3) {
		pDC->DrawText(_T("?"), &rcBox, 0 |DT_LEFT |DT_VCENTER |DT_SINGLELINE);
	} else {
		BYTE x = m_oia[z];

		CString str;
		str.Format("%2d:", 1 +z);
		pDC->DrawText(str, &rcBox, 0 |DT_LEFT |DT_VCENTER |DT_SINGLELINE);
		CSize size = pDC->GetTextExtent(str);
		rcBox.left += size.cx + 1;

		BYTE c0 = 0;
		switch (m_ot) {
		case otWall:    c0 =  9; break;
		case otFloor:   c0 = 10; break;
		case otDoor:    c0 = 11; break;
		case otCreature:c0 = 15; break;
		}
		GetApp()->RenderOrnate64To(pDC, rcBox.left, rcBox.top, c0, x, 64);
	}
}
