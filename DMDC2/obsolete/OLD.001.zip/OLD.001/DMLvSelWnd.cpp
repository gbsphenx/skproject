// DMLvSelWnd.cpp : �C���v�������e�[�V���� �t�@�C��
//

#include "stdafx.h"
#include "exp00069.h"
#include "DMLvSelWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDMLvSelWnd

CDMLvSelWnd::CDMLvSelWnd()
{
}

CDMLvSelWnd::~CDMLvSelWnd()
{
}


BEGIN_MESSAGE_MAP(CDMLvSelWnd, CWnd)
	//{{AFX_MSG_MAP(CDMLvSelWnd)
	ON_WM_PAINT()
	ON_WM_NCCALCSIZE()
	ON_WM_NCPAINT()
	ON_WM_SIZE()
	ON_WM_CREATE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_RBUTTONDOWN()
	ON_WM_RBUTTONUP()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CDMLvSelWnd ���b�Z�[�W �n���h��

void CDMLvSelWnd::OnPaint() 
{
	CPaintDC dc(this);

	COLORREF clr3dFace = GetSysColor(COLOR_3DFACE);
	dc.DrawEdge(m_rcPaint, BDR_SUNKENOUTER, BF_RECT);
	HBRUSH hbrWhite = (HBRUSH)GetStockObject(WHITE_BRUSH);
	HPEN hPenWhite = (HPEN)GetStockObject(WHITE_PEN);

	FrameRect(dc, m_rcArrowLLeft, hbrWhite);
	FrameRect(dc, m_rcArrowRRight, hbrWhite);
	FrameRect(dc, m_rcArrowLeft, hbrWhite);
	FrameRect(dc, m_rcArrowRight, hbrWhite);
	HGDIOBJ hOldPen = dc.SelectObject(hPenWhite);
	dc.Polygon(m_ptsArrowLeft, 3);
	dc.Polygon(m_ptsArrowRight, 3);
	dc.Polygon(&m_ptsArrowLLeft[3], 3);
	dc.Polygon(&m_ptsArrowLLeft[0], 3);
	dc.Polygon(&m_ptsArrowRRight[3], 3);
	dc.Polygon(&m_ptsArrowRRight[0], 3);
	dc.SelectObject(hOldPen);

	switch (m_iHitNow) {
	case HT_ARROWLEFT:
	case HT_ARROWRIGHT:
	case HT_ARROWLLEFT:
	case HT_ARROWRRIGHT:
		CRect rc;
		switch (m_iHitNow) {
		case HT_ARROWLEFT: rc = m_rcArrowLeft; break;
		case HT_ARROWRIGHT: rc = m_rcArrowRight; break;
		case HT_ARROWLLEFT: rc = m_rcArrowLLeft; break;
		case HT_ARROWRRIGHT: rc = m_rcArrowRRight; break;
		}
		rc.DeflateRect(1, 1);
		dc.InvertRect(rc);
		break;
	}

	dc.SetBkMode(TRANSPARENT);
	dc.SetTextColor((COLORREF)0xffffff);

	HGDIOBJ hOldFont = dc.SelectObject(m_fontNice.m_hObject);

	CRect rcRest = m_rcItems;
	int cx = rcRest.Height();
	int n = m_nBox - m_iBoxOff;
	for (int i=0; i<n; i++) {
		if (rcRest.Width() < cx)
			break;
		CRect rcItem(
			rcRest.left,
			rcRest.top,
			rcRest.left + cx,
			rcRest.top + cx);
		FrameRect(dc, rcItem, hbrWhite);
		CString tstr;
		tstr.Format("%u", i + m_iBoxOff);
		dc.DrawText(tstr, rcItem, DT_CENTER|DT_VCENTER|DT_SINGLELINE);
		if (i + m_iBoxOff == m_iBoxSel) {
			rcItem.DeflateRect(1, 1);
			dc.InvertRect(rcItem);
		}

		rcRest.left += cx + 2;
	}

	dc.SelectObject(hOldFont);
}

void CDMLvSelWnd::OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp) 
{
	if (bCalcValidRects) {
		InflateRect(&lpncsp->rgrc[0], -0, -2);
	}
	
	CWnd::OnNcCalcSize(bCalcValidRects, lpncsp);
}

void CDMLvSelWnd::OnNcPaint() 
{
	CRect rc;
	GetWindowRect(rc);
	ScreenToClient(rc);
	CWindowDC dc(this);
	CRect rc2;
	GetClientRect(rc2);
	rc2 -= rc.TopLeft();
	dc.ExcludeClipRect(&rc2);
	rc -= rc.TopLeft();
	dc.FillSolidRect(&rc, GetSysColor(COLOR_3DFACE));
}

void CDMLvSelWnd::OnSize(UINT nType, int cx, int cy) 
{
	CWnd::OnSize(nType, cx, cy);

	const nMergin = 2, nButtonSize = 12;
	m_rcPaint.SetRect(0, 0, cx, cy);
	m_rcPaint.DeflateRect(2, 2);
	m_rcArrowLLeft.right = (m_rcArrowLLeft.left = m_rcPaint.left) + nButtonSize;
	m_rcArrowRRight.left = (m_rcArrowRRight.right = m_rcPaint.right) - nButtonSize;
	m_rcArrowLeft.right = (m_rcArrowLeft.left = m_rcArrowLLeft.right + nMergin) + nButtonSize;
	m_rcArrowRight.left = (m_rcArrowRight.right = m_rcArrowRRight.left - nMergin) - nButtonSize;
	m_rcItems.top = m_rcArrowLLeft.top = m_rcArrowLeft.top = m_rcArrowRRight.top = m_rcArrowRight.top = m_rcPaint.top;
	m_rcItems.bottom = m_rcArrowLeft.bottom = m_rcArrowLLeft.bottom = m_rcArrowRight.bottom = m_rcArrowRRight.bottom = m_rcPaint.bottom;
	m_rcItems.left = m_rcArrowLeft.right + nMergin;
	m_rcItems.right = m_rcArrowRight.left - nMergin;
	m_rcPaint.InflateRect(2, 2);

	CPoint t;
	t = m_rcArrowLeft.CenterPoint();
	m_ptsArrowLeft[0].x = t.x +2;
	m_ptsArrowLeft[0].y = t.y -6;
	m_ptsArrowLeft[1].x = t.x +2;
	m_ptsArrowLeft[1].y = t.y +4;
	m_ptsArrowLeft[2].x = t.x -3;
	m_ptsArrowLeft[2].y = t.y -1;
	t = m_rcArrowRight.CenterPoint();
	m_ptsArrowRight[0].x = t.x -3;
	m_ptsArrowRight[0].y = t.y -6;
	m_ptsArrowRight[1].x = t.x -3;
	m_ptsArrowRight[1].y = t.y +4;
	m_ptsArrowRight[2].x = t.x +2;
	m_ptsArrowRight[2].y = t.y -1;
	t = m_rcArrowLLeft.CenterPoint();
	m_ptsArrowLLeft[0].x = t.x +3;
	m_ptsArrowLLeft[0].y = t.y -4;
	m_ptsArrowLLeft[1].x = t.x -0;
	m_ptsArrowLLeft[1].y = t.y -1;
	m_ptsArrowLLeft[2].x = t.x +3;
	m_ptsArrowLLeft[2].y = t.y +2;

	m_ptsArrowLLeft[3].x = t.x -1;
	m_ptsArrowLLeft[3].y = t.y -4;
	m_ptsArrowLLeft[4].x = t.x -4;
	m_ptsArrowLLeft[4].y = t.y -1;
	m_ptsArrowLLeft[5].x = t.x -1;
	m_ptsArrowLLeft[5].y = t.y +2;
	t = m_rcArrowRRight.CenterPoint();
	m_ptsArrowRRight[0].x = t.x +0;
	m_ptsArrowRRight[0].y = t.y -4;
	m_ptsArrowRRight[1].x = t.x +3;
	m_ptsArrowRRight[1].y = t.y -1;
	m_ptsArrowRRight[2].x = t.x +0;
	m_ptsArrowRRight[2].y = t.y +2;

	m_ptsArrowRRight[3].x = t.x -4;
	m_ptsArrowRRight[3].y = t.y -4;
	m_ptsArrowRRight[4].x = t.x -1;
	m_ptsArrowRRight[4].y = t.y -1;
	m_ptsArrowRRight[5].x = t.x -4;
	m_ptsArrowRRight[5].y = t.y +2;

	m_nBoxInPaint = (m_rcItems.Width() + 1) / (m_rcItems.Height() + 2);
}

int CDMLvSelWnd::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	m_iBoxOff = 0;
	m_nBox = 0;
	m_iBoxSel = -1;
	m_iHitNow = -1;

	LOGFONT lfNice;
	ReadFontTemplateFrom(lfNice, IDS_FONTTEMP_DMLVSEL, ";;;;;;;;;;;;;;");
	m_fontNice.DeleteObject();
	if (!m_fontNice.CreateFontIndirect(&lfNice))
		return -1;
	
	return 0;
}

void CDMLvSelWnd::OnLButtonDown(UINT nFlags, CPoint point) 
{
	if (HookForLButton(point))
		return;

	CWnd::OnLButtonDown(nFlags, point);
}

void CDMLvSelWnd::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	if (HookForLButton(point))
		return;

	CWnd::OnLButtonDblClk(nFlags, point);
}

int CDMLvSelWnd::HitTest(CPoint point, int &iItem)
{
	if (m_rcPaint.PtInRect(point)) {
		if (point.x < m_rcArrowLLeft.right)
			return HT_ARROWLLEFT;
		if (point.x < m_rcArrowLeft.right)
			return HT_ARROWLEFT;
		if (m_rcArrowRRight.left < point.x)
			return HT_ARROWRRIGHT;
		if (m_rcArrowRight.left < point.x)
			return HT_ARROWRIGHT;
		CRect rc;
		for (int i=m_iBoxOff; i<m_iBoxOff+m_nBoxInPaint; i++) {
			if (!GetItemRect(i, rc))
				continue;
			if (rc.PtInRect(point)) {
				iItem = i;
				return HT_ITEM;
			}
		}
	}

	return HT_NONE;
}

void CDMLvSelWnd::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: ���̈ʒu�Ƀ��b�Z�[�W �n���h���p�̃R�[�h��ǉ����邩�܂��̓f�t�H���g�̏������Ăяo���Ă�������
	
	CWnd::OnRButtonDown(nFlags, point);
}

void CDMLvSelWnd::OnRButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: ���̈ʒu�Ƀ��b�Z�[�W �n���h���p�̃R�[�h��ǉ����邩�܂��̓f�t�H���g�̏������Ăяo���Ă�������
	
	CWnd::OnRButtonUp(nFlags, point);
}

void CDMLvSelWnd::NotifySetItemPos()
{
	GetParent()->SendMessage(WM_COMMAND, MAKELONG(GetDlgCtrlID(), DMLVSN_SELCHANGE), (LPARAM)(HWND)*this);
}

BOOL CDMLvSelWnd::HookForLButton(CPoint point)
{
	CRect rcHi;
	int i, iHitTest = -1;
	switch (iHitTest = HitTest(point, i)) {
	case HT_ARROWLEFT:
		MoveDelta(-1);
		rcHi = m_rcArrowLeft;
		break;
	case HT_ARROWRIGHT:
		MoveDelta(+1);
		rcHi = m_rcArrowRight;
		break;
	case HT_ARROWLLEFT:
		MoveDelta(-m_nBoxInPaint);
		rcHi = m_rcArrowLLeft;
		break;
	case HT_ARROWRRIGHT:
		MoveDelta(+m_nBoxInPaint);
		rcHi = m_rcArrowRRight;
		break;
	case HT_ITEM:
		m_iBoxSel = i;
		Invalidate();
		NotifySetItemPos();
		return TRUE;
	default:
		return FALSE;
	}

	MSG msg;
	SetCapture();

	m_iHitNow = iHitTest;
	InvalidateRect(rcHi);
	UpdateWindow();
	while (GetCapture() == this) {
		if (!GetMessage(&msg, NULL, 0, 0)) {
			AfxPostQuitMessage(msg.wParam);
			break;
		}
		if (msg.message == WM_LBUTTONUP) {
			break;
		}
		if (msg.message == WM_MOUSEMOVE) {
			CPoint pt(LOWORD(msg.lParam), HIWORD(msg.lParam));
			int i;
			int iHit = HitTest(pt, i);
			if (iHit != m_iHitNow)
				m_iHitNow = -1;
			InvalidateRect(rcHi);
			UpdateWindow();
		}
		if (msg.message == WM_KEYDOWN) {
			if (msg.wParam == VK_ESCAPE)
				break;
		}
	}
	ReleaseCapture();
	m_iHitNow = -1;
	InvalidateRect(rcHi);
	return FALSE;
}
