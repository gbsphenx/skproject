#if !defined(AFX_DMLVSELWND_H__462AF3C7_D78D_4FFE_8EB3_545BF6079E95__INCLUDED_)
#define AFX_DMLVSELWND_H__462AF3C7_D78D_4FFE_8EB3_545BF6079E95__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DMLvSelWnd.h : �w�b�_�[ �t�@�C��
//

#define HT_NONE	0
#define HT_ARROWLEFT	1
#define HT_ARROWRIGHT	2
#define HT_ITEM	3
#define HT_ARROWLLEFT	4
#define HT_ARROWRRIGHT	5

/////////////////////////////////////////////////////////////////////////////
// CDMLvSelWnd �E�B���h�E

#define DMLVSN_SELCHANGE	1

class CDMLvSelWnd : public CWnd
{
	// 
	CRect m_rcPaint, m_rcArrowLeft, m_rcArrowRight;
	// 
	CRect m_rcArrowLLeft, m_rcArrowRRight;
	// 
	CRect m_rcItems;
	// 
	POINT m_ptsArrowLeft[3];
	// 
	POINT m_ptsArrowRight[3];
	// 
	POINT m_ptsArrowLLeft[6];
	// 
	POINT m_ptsArrowRRight[6];
	// 
	int m_nBox, m_iBoxOff, m_iBoxSel, m_nBoxInPaint;
	// 
	CFont m_fontNice;
	// 
	int m_iHitNow;

	// 
	void NotifySetItemPos();

public:
	// 
	BOOL Create(DWORD dwStyle, CRect rc, CWnd *pParentWnd, UINT nID)
	{
		LPCTSTR lpszClassName = AfxRegisterWndClass(
			CS_DBLCLKS|CS_HREDRAW|CS_VREDRAW,
			::LoadCursor(NULL, IDC_ARROW),
			::CreateSolidBrush((COLORREF)0x000000),
			::LoadIcon(NULL, IDI_ASTERISK));
		if (!CWnd::Create(lpszClassName, NULL, dwStyle, rc, pParentWnd, nID, NULL))
			return FALSE;
		return TRUE;
	}
	// 
	int HitTest(CPoint point, int &iItem);
	// 
	BOOL MoveDelta(int x, BOOL bRedraw = TRUE)
	{
		int n = 0;
		while (x < 0 && m_iBoxOff != 0) {
			x++; m_iBoxOff--;
			n++;
		}
		while (x > 0 && m_iBoxOff + 1 <= m_nBox - m_nBoxInPaint) {
			x--; m_iBoxOff++;
			n++;
		}
		if (bRedraw && n)
			Invalidate();
		return TRUE;
	}
	// 
	BOOL GetItemRect(int x, RECT &rc)
	{
		if (x < 0 || m_nBox <= x)
			return FALSE;

		int cy = m_rcItems.Height();
		int cx = cy + 2;
		rc.left = m_rcItems.left + (-m_iBoxOff + x) * cx;
		rc.right = rc.left + cx;
		rc.top = m_rcItems.top;
		rc.bottom = m_rcItems.bottom;

		return TRUE;
	}
	// 
	BOOL IsItemVisible(int x)
	{
		if (x < 0 || m_nBox <= x)
			return FALSE;
		if (x < m_iBoxOff || m_iBoxOff + m_nBoxInPaint <= x)
			return FALSE;
		return TRUE;
	}
	// 
	BOOL SetItemCount(int x)
	{
		if (x < 0)
			return FALSE;
		m_nBox = x;
		if (m_nBox <= m_iBoxSel)
			m_iBoxSel = -1;
		m_iBoxOff = __max(0, __min(m_iBoxOff, m_nBox - m_nBoxInPaint));
		int iBoxSel = __max(0, __min(m_iBoxSel, m_nBox - 1));
		Invalidate();
		if (iBoxSel != m_iBoxSel) {
			m_iBoxSel = iBoxSel;
			NotifySetItemPos();
		}
		return TRUE;
	}
	// 
	int GetItemCount()
	{
		return m_nBox;
	}
	// 
	BOOL SetItemPos(int x)
	{
		if (x < 0 || m_nBox <= x)
			return FALSE;
		if (m_iBoxSel != x) {
			m_iBoxSel = x;
			Invalidate();
			NotifySetItemPos();
		}
		return TRUE;
	}
	// 
	int GetItemPos()
	{
		return m_iBoxSel;
	}
	// 
	BOOL HookForLButton(CPoint point);

// �R���X�g���N�V����
public:
	CDMLvSelWnd();

// �A�g���r���[�g
public:

// �I�y���[�V����
public:

// �I�[�o�[���C�h
	// ClassWizard �͉��z�֐��̃I�[�o�[���C�h�𐶐����܂��B

	//{{AFX_VIRTUAL(CDMLvSelWnd)
	//}}AFX_VIRTUAL

// �C���v�������e�[�V����
public:
	virtual ~CDMLvSelWnd();

	// �������ꂽ���b�Z�[�W �}�b�v�֐�
protected:
	//{{AFX_MSG(CDMLvSelWnd)
	afx_msg void OnPaint();
	afx_msg void OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp);
	afx_msg void OnNcPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ �͑O�s�̒��O�ɒǉ��̐錾��}�����܂��B

#endif // !defined(AFX_DMLVSELWND_H__462AF3C7_D78D_4FFE_8EB3_545BF6079E95__INCLUDED_)
