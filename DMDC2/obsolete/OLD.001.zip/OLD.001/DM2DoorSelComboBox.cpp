// DM2DoorSelComboBox.cpp : �C���v�������e�[�V���� �t�@�C��
//

#include "stdafx.h"
#include "exp00069.h"
#include "DM2DoorSelComboBox.h"
#include "CompatDC.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDM2DoorSelComboBox

CDM2DoorSelComboBox::CDM2DoorSelComboBox()
{

}

BEGIN_MESSAGE_MAP(CDM2DoorSelComboBox, CComboBox)
	//{{AFX_MSG_MAP(CDM2DoorSelComboBox)
		// ���� - ClassWizard �͂��̈ʒu�Ƀ}�b�s���O�p�̃}�N����ǉ��܂��͍폜���܂��B
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDM2DoorSelComboBox ���b�Z�[�W �n���h��

void CDM2DoorSelComboBox::Init(bool fDoor, bool fWall)
{
	int t = fDoor
		? (fWall ? tDoorOrnates : tDoors)
		: (fWall ? tWallOrnates : tFloorOrnates)
		;

	Init(t);
}

void CDM2DoorSelComboBox::Init(int t)
{
	ResetContent();

	SetItemHeight(-1, m_cy = 66);

	m_t = t;

	int n = 256;

	for (int i = 0; i < n; i++) {
		AddString(_T("Text"));
		SetItemHeight(i, m_cy);
	}
}

void CDM2DoorSelComboBox::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	CDC *pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
	CRect rc = lpDrawItemStruct->rcItem;
	int i = lpDrawItemStruct->itemID;

	if (pDC == NULL) return;

	BOOL fSel = (lpDrawItemStruct->itemState & ODS_SELECTED);

	COLORREF clrBack = GetSysColor(fSel ? COLOR_HIGHLIGHT : COLOR_WINDOW);
	COLORREF clrText = GetSysColor(fSel ? COLOR_HIGHLIGHTTEXT : COLOR_WINDOWTEXT);

	CBrush br;
	br.CreateSolidBrush(clrBack);
	pDC->FillRect(&rc, &br);

	CRect rcBox = rc;
	rcBox.DeflateRect(1, 1);

	pDC->SetBkColor(clrBack);
	pDC->SetTextColor(clrText);

	if (i < 0) {
		pDC->DrawText(_T("(No)"), &rcBox, 0 |DT_LEFT |DT_VCENTER |DT_SINGLELINE);
	} else if (i < 256) {
		BYTE x = i;

		CString str;
		str.Format("%3d:", i);
		pDC->DrawText(str, &rcBox, 0 |DT_LEFT |DT_VCENTER |DT_SINGLELINE);
		CSize size = pDC->GetTextExtent(str);
		rcBox.left += size.cx + 1;

		BYTE c0 = m_t;

		GetApp()->RenderOrnate64To(pDC, rcBox.left, rcBox.top, c0, x, 64);
	}
}
